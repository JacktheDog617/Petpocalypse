package collegecatnip.petpocalypse.ui.petbox

import androidx.lifecycle.ViewModel

class PetBoxViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}